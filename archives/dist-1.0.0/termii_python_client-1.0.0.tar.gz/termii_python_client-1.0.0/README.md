<div align="center">
    <h1>Termii Python</h1>
</div>